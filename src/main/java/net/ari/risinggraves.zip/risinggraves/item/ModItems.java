package net.oliver.risinggraves.item;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.oliver.risinggraves.RisingGraves;


public class ModItems {
    public static final DeferredRegister<Item>  ITEMS =
           DeferredRegister.create(ForgeRegistries.ITEMS, RisingGraves.MOD_ID);


public static final RegistryObject<Item> LIGHTER = ITEMS.register ( "lighter",
        () -> new Item(new Item.Properties()));




public static final RegistryObject<Item> SAPPHIRE = ITEMS.register ("sapphire",
        () -> new Item(new Item.Properties()));

public static final RegistryObject<SwordItem> SAPPHIRE_SWORD = ITEMS.register ("sapphire_sword",
            () -> new SwordItem(Tiers.NETHERITE, 6, 2.7f, new Item.Properties()));




    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}

