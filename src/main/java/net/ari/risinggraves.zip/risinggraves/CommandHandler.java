package net.oliver.risinggraves;
import net.minecraft.world.scores.Scoreboard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.awt.*;

import static net.oliver.risinggraves.RisingGraves.zombiesMode;
import static sun.net.www.protocol.http.AuthCacheValue.Type.Server;

@Mod.EventBusSubscriber(modid = "risinggraves", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class CommandHandler {


    private static final Logger LOGGER = LogManager.getLogger();

    @SubscribeEvent
    public static void registerCommandsEvent (RegisterCommandsEvent event) {
        //Register the command
        CommandDispatcher<CommandSourceStack> commandDispatcher = event.getDispatcher();

        LiteralArgumentBuilder<CommandSourceStack> cmd = Commands.literal("activate")
                .requires((commandSource) -> commandSource.hasPermission(2))
                .executes(context -> execute(context));

        commandDispatcher.register(cmd);
    }

    private static int execute(CommandContext<CommandSourceStack> context) {
        zombiesMode = !zombiesMode;
        LOGGER.info("Command bloody works!");

        if (zombiesMode = true) {
            Scoreboard scoreboard = new Scoreboard();

        }
        //Command Logic here
        return 1;
    }
}
