package net.oliver.risinggraves.crate;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChestList {

    public List <ItemStack> Storage = new ArrayList<>();
    Storage.add(Items.WOODEN_SWORD);
    Storage.add(Items.STONE_SWORD);
    Storage.add(Items.IRON_SWORD);
    Storage.add(Items.GOLDEN_SWORD);
    Storage.add(Items.DIAMOND_SWORD);
    Storage.add(Items.DIAMOND_AXE);
    Storage.add(Items.GOLDEN_AXE);
    Storage.add(Items.IRON_AXE);
    Storage.add(Items.STONE_AXE);
    Storage.add(Items.WOODEN_AXE);

    Storage.add(Items.DIAMOND_SHOVEL
    );
    Storage.add(Items.IRON_SHOVEL);T
    Storage.add(Items.STONE_SHOVEL)

    Storage.add(Items.GOLDEN_PICKAXE);




}
