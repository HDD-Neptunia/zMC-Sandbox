package net.oliver.risinggraves.explosion;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class Explosion {

  /*  public static void onPlayerAttackEntity(AttackEntityEvent event) {
        if (event.getTarget() instanceof EntityZombie && event.getEntityLiving() instanceof PlayerEntity)


   */
}
