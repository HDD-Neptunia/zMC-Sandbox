package net.oliver.risinggraves.explosion;

public class ExplosionListener {
}
