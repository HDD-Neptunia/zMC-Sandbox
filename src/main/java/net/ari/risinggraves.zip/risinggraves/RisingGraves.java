package net.oliver.risinggraves;

import com.mojang.logging.LogUtils;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.CreativeModeTabEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.oliver.risinggraves.block.ModBlocks;
import net.oliver.risinggraves.item.ModItems;
import org.slf4j.Logger;

// The value here should match an entry in the META-INF/mods.toml file
@Mod(RisingGraves.MOD_ID)
public class RisingGraves
{
    public static final String MOD_ID = "risinggraves";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static boolean zombiesMode = false;
    public RisingGraves()
    {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.register(modEventBus);
        ModBlocks.register(modEventBus);

        // Register the commonSetup method for mod loading
        modEventBus.addListener(this::commonSetup);

        //Register the main class event for the Forge event bus
        MinecraftForge.EVENT_BUS.register(this);

        //Register Command Handler
        MinecraftForge.EVENT_BUS.register(new CommandHandler());

        // Register the item to a creative tab
        modEventBus.addListener(this::addCreative);
    }

    private void commonSetup(final FMLCommonSetupEvent event)
    {

    }

    private void addCreative(CreativeModeTabEvent.BuildContents event) {
        if (event.getTab() == CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(ModBlocks.SAPPHIRE_ORE);
            event.accept(ModBlocks.BLOCK_OF_SAPPHIRE);
            event.accept(ModBlocks.MYSTERY_CRATE);
        }


        {
            if (event.getTab() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
                event.accept(ModItems.LIGHTER);
            }
            if (event.getTab() == CreativeModeTabs.COMBAT) {
                event.accept(ModItems.SAPPHIRE_SWORD);
            }
            if (event.getTab() == CreativeModeTabs.INGREDIENTS) {
                event.accept(ModItems.SAPPHIRE);


                /*Create own tabs for mod items*/
            }

        }
    }
    // You can use SubscribeEvent and let the Event Bus discover methods to call

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)


    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event)
        {

        }

    }
}
