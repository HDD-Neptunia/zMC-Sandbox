package net.oliver.risinggraves.crate;

import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "risinggraves", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class EventListeners {
    @SubscribeEvent
    public static void onZombieHit(LivingHurtEvent event) {
        if (event.getEntity() instanceof Zombie && event.getEntity() instanceof Player) {

        }
    }




}
