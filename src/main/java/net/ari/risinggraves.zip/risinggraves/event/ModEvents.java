package net.oliver.risinggraves.event;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.oliver.risinggraves.RisingGraves;

public class ModEvents {
    @Mod.EventBusSubscriber(modid = RisingGraves.MOD_ID)

    public static class OpenChest {

        //if(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock)

    }



}
