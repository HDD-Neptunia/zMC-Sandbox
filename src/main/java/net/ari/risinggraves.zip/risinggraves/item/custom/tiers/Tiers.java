package net.oliver.risinggraves.item.custom.tiers;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;
import net.oliver.risinggraves.item.ModItems;

public class Tiers {
    public static final Tier Sapphire = new ForgeTier(
            5,
            3863,
            1.3f,
            5,
            350,
            null,
            () -> Ingredient.of(ModItems.SAPPHIRE.get()));
}



