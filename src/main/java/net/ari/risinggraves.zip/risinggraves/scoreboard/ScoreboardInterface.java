package net.oliver.risinggraves.scoreboard;

import net.minecraft.server.commands.ScoreboardCommand;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ScoreboardInterface {

    public String Check = "Valid";
    public boolean isActive = false;

    public void ToggleActive() {isActive = !isActive;
    }


    }
